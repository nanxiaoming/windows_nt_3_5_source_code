#ifdef i386
#define CARDTXXX_H "CARDT13B.H"
#include "..\..\source\portio.c"
#endif
