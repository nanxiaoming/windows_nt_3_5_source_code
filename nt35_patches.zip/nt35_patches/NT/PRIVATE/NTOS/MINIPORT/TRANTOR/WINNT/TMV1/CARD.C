#ifdef i386
#define CARDTXXX_H "CARDTMV1.H"
#include "..\..\source\cardtmv1.c"
#endif
