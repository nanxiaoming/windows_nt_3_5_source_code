#ifdef i386
#define CARDTXXX_H "CARDT338.H"
#include "..\..\source\cardt338.c"
#endif
