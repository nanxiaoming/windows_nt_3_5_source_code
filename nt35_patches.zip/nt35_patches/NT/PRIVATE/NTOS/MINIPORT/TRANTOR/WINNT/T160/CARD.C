#ifdef i386
#define CARDTXXX_H "CARDT160.H"
#include "..\..\source\cardt160.c"
#endif
