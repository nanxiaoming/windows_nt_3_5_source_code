#ifdef i386
#define CARDTXXX_H "CARDTMV1.H"
#include "..\..\source\n5380.c"
#endif
