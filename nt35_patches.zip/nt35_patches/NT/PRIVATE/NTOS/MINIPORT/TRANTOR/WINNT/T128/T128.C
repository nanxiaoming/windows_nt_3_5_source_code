#ifdef i386
#define CARDTXXX_H "CARDT128.H"
#include "..\..\source\t128.c"
#endif
