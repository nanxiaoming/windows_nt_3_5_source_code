#ifdef i386
#define CARDTXXX_H "CARDT160.H"
#include "..\..\source\scsifnc.c"
#endif
