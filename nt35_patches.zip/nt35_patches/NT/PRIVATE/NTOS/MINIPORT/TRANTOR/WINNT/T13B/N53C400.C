#ifdef i386
#define CARDTXXX_H "CARDT13B.H"
#include "..\..\source\n53c400.c"
#endif
