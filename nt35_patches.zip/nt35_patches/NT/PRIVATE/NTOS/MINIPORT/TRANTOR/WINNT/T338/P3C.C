#ifdef i386
#define CARDTXXX_H "CARDT338.H"
#include "..\..\source\t338.c"
#endif
