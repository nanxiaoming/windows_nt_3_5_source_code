#ifdef i386
#define CARDTXXX_H "CARDT160.H"
#include "..\..\source\pc9010.c"
#endif
