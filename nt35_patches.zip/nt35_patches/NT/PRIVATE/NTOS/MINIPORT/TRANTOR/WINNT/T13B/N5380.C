#ifdef i386
#define CARDTXXX_H "CARDT13B.H"
#include "..\..\source\n5380.c"
#endif
