#ifdef i386
#include "..\..\source\cardutil.c"
#endif
