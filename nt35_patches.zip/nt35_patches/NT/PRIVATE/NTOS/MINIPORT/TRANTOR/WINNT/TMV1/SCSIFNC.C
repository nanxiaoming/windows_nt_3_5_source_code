#ifdef i386
#define CARDTXXX_H "CARDTMV1.H"
#include "..\..\source\scsifnc.c"
#endif
