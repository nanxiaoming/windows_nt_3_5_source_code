#ifdef i386
#define CARDTXXX_H "CARDT128.H"
#include "..\..\source\port.c"
#endif
