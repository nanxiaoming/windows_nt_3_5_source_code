#ifdef i386
#define CARDTXXX_H "CARDT348.H"
#include "..\..\source\scsifnc.c"
#endif
