#ifdef i386
#define CARDTXXX_H "CARDT348.H"
#include "..\..\source\parallel.c"
#endif
