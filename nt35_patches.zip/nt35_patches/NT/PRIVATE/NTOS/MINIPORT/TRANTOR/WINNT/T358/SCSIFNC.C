#define CARDTXXX_H "CARDT358.H"
#include "..\..\source\scsifnc.c"
