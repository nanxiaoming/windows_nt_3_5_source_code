#ifdef i386
#define CARDTXXX_H "CARDT338.H"
#include "..\..\source\cardutil.c"
#endif
